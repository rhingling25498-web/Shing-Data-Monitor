package com.daily.wifidatatracker
import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit
class UsageWorker(c: Context, p: WorkerParameters): Worker(c,p) {
    override fun doWork(): Result {
        val s=PlanStore(applicationContext)
        if(s.startMillis<=0 || s.planBytes<=0) return Result.success()
        WifiUsageReader(applicationContext).read(s.startMillis)?.let { s.wifiBytes=it }
        val left=(s.planBytes-s.wifiBytes-s.hotspotBytes).coerceAtLeast(0)
        val pct=left.toDouble()/s.planBytes
        if(pct<=0.20) {
            val nm=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(android.app.NotificationChannel("data_alert","Data alerts",android.app.NotificationManager.IMPORTANCE_DEFAULT))
            val note=androidx.core.app.NotificationCompat.Builder(applicationContext,"data_alert")
                .setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle(if(pct<=0.10) "Data almost finished" else "Low data warning")
                .setContentText("${fmt(left)} remaining").build()
            try { nm.notify(1,note) } catch (_: Exception) {}
        }
        return Result.success()
    }
    companion object {
        fun schedule(c: Context) {
            val r=PeriodicWorkRequestBuilder<UsageWorker>(15,TimeUnit.MINUTES).build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork("shing_data_monitor",ExistingPeriodicWorkPolicy.UPDATE,r)
        }
    }
}
