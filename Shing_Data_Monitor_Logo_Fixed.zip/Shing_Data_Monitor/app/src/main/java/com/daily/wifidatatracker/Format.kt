package com.daily.wifidatatracker
import java.util.Locale
fun fmt(bytes: Long): String {
    if (bytes<1024) return "$bytes B"
    var n=bytes.toDouble(); var i=-1
    val u=arrayOf("KB","MB","GB","TB")
    do { n/=1024.0; i++ } while(n>=1024 && i<u.lastIndex)
    return String.format(Locale.US,"%.2f %s",n,u[i])
}
