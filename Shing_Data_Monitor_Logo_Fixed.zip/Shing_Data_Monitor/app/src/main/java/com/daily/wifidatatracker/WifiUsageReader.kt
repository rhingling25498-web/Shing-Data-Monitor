package com.daily.wifidatatracker
import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Process
class WifiUsageReader(private val c: Context) {
    fun hasAccess(): Boolean {
        val a=c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)==AppOpsManager.MODE_ALLOWED
    }
    fun read(start: Long): Long? {
        if (!hasAccess() || start<=0) return null
        return try {
            val n=c.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val b=n.querySummaryForDevice(ConnectivityManager.TYPE_WIFI, null, start, System.currentTimeMillis())
            (b.rxBytes+b.txBytes).coerceAtLeast(0L)
        } catch (_: Exception) { null }
    }
}
