package com.daily.wifidatatracker
import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity: Activity() {
    private lateinit var s: PlanStore
    private lateinit var wifi: TextView
    private lateinit var hot: TextView
    private lateinit var used: TextView
    private lateinit var left: TextView
    private lateinit var info: TextView
    private fun dp(x:Int)= (x*resources.displayMetrics.density).toInt()
    private fun bg(color:Int)=GradientDrawable().apply { setColor(color); cornerRadius=dp(18).toFloat() }
    private fun label(t:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply {
        text=t; textSize=size; setTextColor(color); setPadding(0,dp(4),0,dp(4))
        if(bold) setTypeface(typeface,Typeface.BOLD)
    }
    private fun card():LinearLayout=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(15),dp(18),dp(15))
        background=bg(Color.WHITE); elevation=dp(2).toFloat()
    }
    private fun addCard(parent:LinearLayout, child:View, top:Int=12) {
        parent.addView(child,LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(top) })
    }
    override fun onCreate(b:Bundle?) {
        super.onCreate(b); s=PlanStore(this); UsageWorker.schedule(this)
        val sc=ScrollView(this).apply { setBackgroundColor(0xFFF3F6FC.toInt()) }
        val root=LinearLayout(this).apply { orientation=1; setPadding(dp(16),dp(16),dp(16),dp(24)) }
        sc.addView(root); setContentView(sc)
        val header=card().apply {
            background=bg(0xFF102A56.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            val logo = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.shing_data_monitor_logo)
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                contentDescription = "Shing Data Monitor Data Plan logo"
            }
            addView(logo, LinearLayout.LayoutParams(-1, dp(260)))
        }
        root.addView(header)
        val c=card()
        c.addView(label("DATA PLAN REMAINING",12f,0xFF65748B.toInt(),true))
        left=label("Not set",32f,0xFF102A56.toInt(),true); c.addView(left)
        info=label("Set your package to begin",13f,0xFF65748B.toInt()); c.addView(info)
        addCard(root,c)
        val row=LinearLayout(this).apply { orientation=0 }
        val wc=card(); wc.addView(label("Phone WiFi",13f,0xFF65748B.toInt(),true)); wifi=label("0 B",21f,0xFF2563EB.toInt(),true); wc.addView(wifi)
        val hc=card(); hc.addView(label("Hotspot",13f,0xFF65748B.toInt(),true)); hot=label("0 B",21f,0xFF0F9D78.toInt(),true); hc.addView(hot)
        row.addView(wc,LinearLayout.LayoutParams(0,dp(92),1f).apply { marginEnd=dp(6) })
        row.addView(hc,LinearLayout.LayoutParams(0,dp(92),1f).apply { marginStart=dp(6) })
        addCard(root,row)
        val tc=card(); tc.addView(label("TOTAL DATA USED",12f,0xFF65748B.toInt(),true))
        used=label("0 B",24f,0xFF102A56.toInt(),true); tc.addView(used); addCard(root,tc)
        val buttons=LinearLayout(this).apply { orientation=0 }
        buttons.addView(btn("Set / Renew Plan"){planDialog()},LinearLayout.LayoutParams(0,dp(52),1f).apply { marginEnd=dp(5) })
        buttons.addView(btn("Enter Hotspot"){hotDialog()},LinearLayout.LayoutParams(0,dp(52),1f).apply { marginStart=dp(5) })
        addCard(root,buttons)
        addCard(root,btn("Enable Usage Access") {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            catch(_:Exception) { Toast.makeText(this,"Open Settings > Special app access > Usage access.",Toast.LENGTH_LONG).show() }
        })
        val details=card()
        details.addView(label("PLAN DETAILS",13f,0xFF65748B.toInt(),true))
        details.addView(label("WiFi usage is read from Android system statistics.",13f,0xFF26364D.toInt()))
        details.addView(label("Hotspot usage may need manual entry depending on phone brand.",13f,0xFF26364D.toInt()))
        addCard(root,details)
        addCard(root,label("Low-data alerts: 20% and 10%. Background checks run approximately every 15 minutes (Android may delay them).",12f,0xFF65748B.toInt()))
        refresh()
    }
    override fun onResume(){ super.onResume(); if(::s.isInitialized) refresh() }
    private fun btn(t:String,action:()->Unit)=Button(this).apply {
        text=t; isAllCaps=false; textSize=13f; setTextColor(Color.WHITE); background=bg(0xFF2563EB.toInt())
        setOnClickListener { action() }
    }
    private fun planDialog() {
        val e=EditText(this).apply { hint="Package size in GB (e.g. 30)"; inputType=8194 }
        AlertDialog.Builder(this).setTitle("Set / Renew Data Plan")
            .setMessage("Enter your package size. Saving starts a new plan and resets usage totals.")
            .setView(e).setPositiveButton("Save"){_,_-> val n=e.text.toString().toDoubleOrNull()
                if(n==null || n<=0) Toast.makeText(this,"Enter a valid GB amount.",Toast.LENGTH_SHORT).show()
                else { s.newPlan(n); refresh() }
            }.setNegativeButton("Cancel",null).show()
    }
    private fun hotDialog() {
        val e=EditText(this).apply { hint="Total hotspot used in GB"; inputType=8194; setText(String.format(Locale.US,"%.2f",s.hotspotBytes/1073741824.0)) }
        AlertDialog.Builder(this).setTitle("Hotspot Usage")
            .setMessage("Enter the total hotspot data used for this plan. This replaces the previous entered amount.")
            .setView(e).setPositiveButton("Save"){_,_-> val n=e.text.toString().toDoubleOrNull()
                if(n==null || n<0) Toast.makeText(this,"Enter a valid amount.",Toast.LENGTH_SHORT).show()
                else { s.hotspotBytes=(n*1073741824.0).toLong(); refresh() }
            }.setNegativeButton("Cancel",null).show()
    }
    private fun refresh() {
        if(!::s.isInitialized) return
        if(s.startMillis>0) WifiUsageReader(this).read(s.startMillis)?.let { s.wifiBytes=it }
        val total=s.wifiBytes+s.hotspotBytes
        val remain=(s.planBytes-total).coerceAtLeast(0)
        wifi.text=fmt(s.wifiBytes); hot.text=fmt(s.hotspotBytes); used.text=fmt(total)
        if(s.planBytes<=0) { left.text="Not set"; info.text="Set your package to begin" }
        else { left.text=fmt(remain); info.text=String.format(Locale.US,"%.1f%% remaining",remain*100.0/s.planBytes) }
    }
}
