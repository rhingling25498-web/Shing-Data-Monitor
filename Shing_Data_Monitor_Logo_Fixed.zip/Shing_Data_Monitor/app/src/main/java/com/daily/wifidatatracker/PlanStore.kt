package com.daily.wifidatatracker
import android.content.Context
class PlanStore(c: Context) {
    private val p = c.getSharedPreferences("shing_data_monitor", Context.MODE_PRIVATE)
    var planBytes: Long get() = p.getLong("plan", 0L); set(v) { p.edit().putLong("plan", v.coerceAtLeast(0)).apply() }
    var startMillis: Long get() = p.getLong("start", 0L); set(v) { p.edit().putLong("start", v).apply() }
    var hotspotBytes: Long get() = p.getLong("hotspot", 0L); set(v) { p.edit().putLong("hotspot", v.coerceAtLeast(0)).apply() }
    var wifiBytes: Long get() = p.getLong("wifi", 0L); set(v) { p.edit().putLong("wifi", v.coerceAtLeast(0)).apply() }
    fun newPlan(gb: Double) { planBytes=(gb*1073741824.0).toLong(); startMillis=System.currentTimeMillis(); hotspotBytes=0; wifiBytes=0 }
}
