# Shing Data Monitor
Complete Android Studio project for Android 10 (API 29) and newer.

Features:
- Shing Data Monitor branded logo shown in the app dashboard without cropping (FIT_CENTER).
- Set and renew a data package in GB.
- Read phone WiFi usage using Android NetworkStatsManager after Usage Access is granted.
- Track hotspot separately with manual total entry.
- Calculate combined used data and remaining package.
- 20% and 10% low-data notifications using periodic WorkManager checks.

Important limitation: Android does not provide a consistent public API for reading hotspot-client data usage across all Android 10+ brands. This app therefore supports manual hotspot entry rather than pretending automatic tracking works on every phone. WiFi statistics also depend on Usage Access and the phone manufacturer's implementation.

Build requirements: JDK 17, Android Gradle Plugin 8.6.1, Gradle 8.7, Android SDK 35.
Minimum Android version: Android 10 (API 29).
