package com.daily.wifidatatracker

import android.Manifest
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private val store by lazy { PlanStore(this) }
    private val reader by lazy { WifiUsageReader(this) }
    private lateinit var root: LinearLayout
    private var selectedStartMillis = System.currentTimeMillis()
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFFF3F6FB.toInt()
        window.navigationBarColor = 0xFFF3F6FB.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF3F6FB.toInt()) }
        val scroll = ScrollView(this).apply { fillViewport = true; addView(root) }
        setContentView(scroll)
        requestNotificationPermission()
        scheduleWorker()
        renderDashboard()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) renderDashboard() }

    private fun renderDashboard() {
        root.removeAllViews()
        root.addView(text("Shing Data Monitor", 26, 0xFF10243B.toInt(), true).apply { setPadding(dp(22), dp(24), dp(22), dp(2)) })
        root.addView(text("Smart Data. Simple Control.", 14, 0xFF718096.toInt()).apply { setPadding(dp(22), 0, dp(22), dp(16)) })
        val plan = store.getPlan()
        if (plan == null) {
            root.addView(card().apply {
                addView(text("Welcome", 20, 0xFF10243B.toInt(), true))
                addView(text("Enter your data package size and start date to begin tracking.", 14, 0xFF718096.toInt()))
                addView(actionButton("＋  Add Data Package") { showPlanDialog() })
            })
            addFooter(); return
        }

        val allowed = reader.hasUsageAccess()
        var wifiGb = 0.0
        var error: String? = null
        if (allowed) try { wifiGb = reader.bytesToGb(reader.totalWifiBytesSince(plan.startMillis)) }
        catch (e: Exception) { error = e.message ?: "Unable to read WiFi usage." }

        val hotspotGb = plan.hotspotGb
        val totalUsed = wifiGb + hotspotGb
        val remaining = (plan.totalGb - totalUsed).coerceAtLeast(0.0)
        val usedRatio = (totalUsed / plan.totalGb).coerceIn(0.0, 1.0)
        val days = max(1, ((System.currentTimeMillis() - plan.startMillis) / 86_400_000L + 1).toInt())
        val dailyAverage = totalUsed / days
        val estimatedDays = if (dailyAverage > 0.00001) (remaining / dailyAverage).toInt() else -1

        root.addView(card(0xFF10243B.toInt()).apply {
            addView(text("DATA REMAINING", 12, 0xFFB8C9DA.toInt(), true))
            addView(text(fmt(remaining) + " GB", 39, -1, true).apply { setPadding(0, dp(4), 0, 0) })
            addView(text("of ${fmt(plan.totalGb)} GB package", 14, 0xFFB8C9DA.toInt()))
            val bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 1000; progress = ((1.0 - usedRatio) * 1000).toInt()
                progressTintList = android.content.res.ColorStateList.valueOf(0xFF35D39A.toInt())
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFF35506B.toInt())
            }
            addView(bar, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(16); bottomMargin = dp(8) })
            addView(text("${String.format(Locale.US, "%.1f", usedRatio * 100)}% used  •  ${String.format(Locale.US, "%.1f", (1-usedRatio)*100)}% left", 13, 0xFFE1EAF3.toInt()))
        })

        root.addView(card().apply {
            addView(text("Usage Breakdown", 18, 0xFF10243B.toInt(), true))
            addView(infoRow("WiFi used (automatic)", "${fmt(wifiGb)} GB"))
            addView(infoRow("Hotspot shared (manual entry)", "${fmt(hotspotGb)} GB"))
            addView(infoRow("TOTAL USED", "${fmt(totalUsed)} GB", true))
            addView(infoRow("DATA REMAINING", "${fmt(remaining)} GB", true))
            addView(actionButton("＋  Update Hotspot Usage") { showHotspotDialog(hotspotGb) })
        })

        root.addView(card().apply {
            addView(text("Plan Insights", 18, 0xFF10243B.toInt(), true))
            addView(infoRow("Daily average", "${fmt(dailyAverage)} GB/day"))
            addView(infoRow("Days since start", "$days days"))
            addView(infoRow("Estimated days left", if (estimatedDays >= 0) "$estimatedDays days" else "Not enough usage yet"))
            addView(infoRow("Plan started", dateText(plan.startMillis)))
        })

        if (allowed && error == null) addView(historyCard(plan.startMillis))
        if (!allowed) root.addView(card(0xFFFFF4D8.toInt()).apply {
            addView(text("Usage Access Required", 17, 0xFF805B00.toInt(), true))
            addView(text("Allow Usage Access so Android can report this phone's WiFi traffic. This permission is required by Android and must be enabled by you.", 14, 0xFF805B00.toInt()))
            addView(actionButton("Open Usage Access Settings", 0xFFB7791F.toInt()) { reader.openUsageAccessSettings() })
        }) else if (error != null) root.addView(card(0xFFFFEEEE.toInt()).apply {
            addView(text("Usage reading issue", 16, 0xFF9B2525.toInt(), true)); addView(text(error!!, 13, 0xFF9B2525.toInt()))
        })

        root.addView(card(0xFFEAF2FF.toInt()).apply {
            addView(text("Hotspot tracking compatibility", 17, 0xFF1E4D8C.toInt(), true))
            addView(text("Android 10 and newer do not provide one reliable public API for reading tethered-device data on every phone brand. Hotspot usage is therefore entered from your phone's data-usage screen; it is not falsely shown as zero or guessed.", 13, 0xFF315477.toInt()))
        })
        root.addView(card().apply {
            addView(text("Package Management", 18, 0xFF10243B.toInt(), true))
            addView(actionButton("＋  Replace / Renew Package") { showPlanDialog() })
            addView(actionButton("Reset Package", 0xFF64748B.toInt()) {
                AlertDialog.Builder(this@MainActivity).setTitle("Reset package?")
                    .setMessage("The active package and entered hotspot amount will be cleared.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Reset") { _, _ -> store.clearPlan(); renderDashboard() }.show()
            })
        })
        addFooter()
    }

    private fun historyCard(planStart: Long): LinearLayout {
        val box = card()
        box.addView(text("Last 7 Days • WiFi", 18, 0xFF10243B.toInt(), true))
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val today = cal.timeInMillis
        val values = (6 downTo 0).map { offset ->
            val start = today - offset * 86_400_000L
            val from = max(start, planStart)
            val to = if (offset == 0) System.currentTimeMillis() else start + 86_400_000L
            val gb = if (to > from) try { reader.bytesToGb(reader.wifiBytesBetween(from, to)) } catch (_: Exception) { 0.0 } else 0.0
            Pair(start, gb)
        }
        val peak = max(0.01, values.maxOf { it.second })
        values.forEach { (date, gb) ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            line.addView(text(SimpleDateFormat("EEE", Locale.getDefault()).format(Date(date)), 12, 0xFF718096.toInt()), LinearLayout.LayoutParams(dp(42), -2))
            val track = FrameLayout(this).apply { background = rounded(0xFFE8EEF5.toInt(), 12) }
            val fill = View(this).apply { background = rounded(0xFF3478E5.toInt(), 12) }
            track.addView(fill, FrameLayout.LayoutParams(((resources.displayMetrics.widthPixels - dp(160)) * (gb / peak).toFloat().coerceIn(0.02f, 1f)).toInt().coerceAtLeast(1), dp(9), Gravity.START or Gravity.CENTER_VERTICAL))
            line.addView(track, LinearLayout.LayoutParams(0, dp(16), 1f))
            line.addView(text("${fmt(gb)} GB", 11, 0xFF334155.toInt(), true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(65), -2))
            box.addView(line)
        }
        box.addView(text("History uses Android's reported WiFi totals. Hotspot is not included in this chart.", 11, 0xFF8794A5.toInt()))
        return box
    }

    private fun showPlanDialog() {
        val input = EditText(this).apply {
            hint = "e.g. 30"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(store.getPlan()?.totalGb?.toString() ?: "")
        }
        val dateButton = Button(this).apply {
            text = "Start date: ${dateText(selectedStartMillis)}"
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = selectedStartMillis }
                DatePickerDialog(this@MainActivity, { _, y, m, d ->
                    selectedStartMillis = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
                    text = "Start date: ${dateText(selectedStartMillis)}"
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20)); addView(text("Package size (GB)", 14, 0xFF334155.toInt(), true)); addView(input); addView(dateButton) }
        AlertDialog.Builder(this).setTitle("Add Data Package").setView(content).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val gb = input.text.toString().trim().toDoubleOrNull()
                if (gb == null || gb <= 0) Toast.makeText(this, "Enter a valid package size.", Toast.LENGTH_LONG).show()
                else { store.savePlan(gb, selectedStartMillis); scheduleWorker(); renderDashboard(); if (!reader.hasUsageAccess()) reader.openUsageAccessSettings() }
            }.show()
    }

    private fun showHotspotDialog(current: Double) {
        val input = EditText(this).apply { hint = "Total hotspot GB since package start"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(if (current == 0.0) "" else current.toString()) }
        AlertDialog.Builder(this).setTitle("Hotspot Usage (GB)")
            .setMessage("Enter the cumulative hotspot data used since the package start date. Check Settings → Network / SIM → Hotspot & tethering or Data usage on your phone.")
            .setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim().toDoubleOrNull()
                if (value == null || value < 0) Toast.makeText(this, "Enter a valid GB value.", Toast.LENGTH_LONG).show()
                else { store.setHotspotUsage(value); renderDashboard() }
            }.show()
    }

    private fun scheduleWorker() {
        val request = PeriodicWorkRequestBuilder<UsageWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("shing_data_monitor_check", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun card(color: Int = -1) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18)); background = rounded(color, 20); elevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(8), dp(16), dp(8)) }
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD); setPadding(0, dp(4), 0, dp(4))
    }
    private fun infoRow(label: String, value: String, bold: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8))
        addView(text(label, 13, 0xFF718096.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
        addView(text(value, 14, 0xFF10243B.toInt(), true).apply { gravity = Gravity.END })
    }
    private fun actionButton(label: String, color: Int = 0xFF2563EB.toInt(), action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(-1); backgroundTintList = android.content.res.ColorStateList.valueOf(color); setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) }
    }
    private fun addFooter() { root.addView(text("Offline app • Background checks may be delayed by Android battery controls.", 11, 0xFF8794A5.toInt()).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(8), dp(20), dp(24)) }) }
    private fun fmt(value: Double) = String.format(Locale.US, "%.2f", value)
    private fun dateText(millis: Long) = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(millis))
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
