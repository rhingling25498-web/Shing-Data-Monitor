package com.daily.wifidatatracker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class UsageWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val store = PlanStore(applicationContext)
        val plan = store.getPlan() ?: return Result.success()
        val reader = WifiUsageReader(applicationContext)
        if (!reader.hasUsageAccess()) return Result.success()
        return try {
            val wifiGb = reader.bytesToGb(reader.totalWifiBytesSince(plan.startMillis))
            val remaining = (plan.totalGb - wifiGb - plan.hotspotGb).coerceAtLeast(0.0)
            val percent = (remaining / plan.totalGb * 100.0).toInt()
            val threshold = when {
                percent <= 10 -> 10
                percent <= 20 -> 20
                else -> 0
            }
            if (threshold != 0 && threshold != store.getLastAlert()) {
                showWarning(remaining, percent, threshold)
                store.setLastAlert(threshold)
            }
            if (threshold == 0 && store.getLastAlert() != 0) store.setLastAlert(0)
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun showWarning(remaining: Double, percent: Int, threshold: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "data_alerts"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Data alerts", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(if (threshold == 10) "Only 10% data remaining" else "Data is running low")
            .setContentText(String.format("%.2f GB remaining (%d%%)", remaining, percent))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
        try { NotificationManagerCompat.from(applicationContext).notify(300 + threshold, notification) }
        catch (_: SecurityException) { }
    }
}
