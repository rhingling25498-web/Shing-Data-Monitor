package com.daily.wifidatatracker

import android.content.Context

data class DataPlan(
    val totalGb: Double,
    val startMillis: Long,
    val hotspotGb: Double
)

class PlanStore(context: Context) {
    private val prefs = context.getSharedPreferences("shing_data_plan_v2", Context.MODE_PRIVATE)

    fun getPlan(): DataPlan? {
        val total = prefs.getString("total_gb", null)?.toDoubleOrNull() ?: return null
        val start = prefs.getLong("start_millis", 0L)
        if (total <= 0.0 || start <= 0L) return null
        return DataPlan(total, start, prefs.getString("hotspot_gb", "0")?.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0)
    }

    fun savePlan(totalGb: Double, startMillis: Long = System.currentTimeMillis()) {
        prefs.edit()
            .putString("total_gb", totalGb.toString())
            .putLong("start_millis", startMillis)
            .putString("hotspot_gb", "0")
            .putInt("last_alert", 0)
            .apply()
    }

    fun setHotspotUsage(gb: Double) {
        prefs.edit().putString("hotspot_gb", gb.coerceAtLeast(0.0).toString()).apply()
    }

    fun getLastAlert(): Int = prefs.getInt("last_alert", 0)
    fun setLastAlert(value: Int) { prefs.edit().putInt("last_alert", value).apply() }
    fun clearPlan() { prefs.edit().clear().apply() }
}
