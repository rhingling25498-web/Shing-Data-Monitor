# Shing Data Monitor

An offline Android application for Android 10 (API 29) and newer. It compares an entered data-package allowance with device WiFi traffic and a separately entered cumulative hotspot amount.

## Project
- App: Shing Data Monitor
- Package: `com.daily.wifidatatracker`
- Kotlin / Android Gradle Plugin 8.6.1 / Kotlin 2.0.20
- Minimum Android: 10 (API 29)
- Compile / target SDK: 35
- JDK: 17

## Tracking behavior and important Android limitation
- **WiFi usage:** Read from Android `NetworkStatsManager` after the user grants Usage Access in Settings. It is device-reported WiFi traffic, not the router's full household or ISP billing meter. Reporting can vary by device and carrier.
- **Hotspot usage:** Android 10+ does not expose a consistent public API that reports tethered-client byte totals across all OEMs. Samsung, Xiaomi/Redmi, OPPO, vivo, TECNO, Infinix and other vendors can differ. This app therefore provides a cumulative manual hotspot GB entry. It never pretends that an unavailable hotspot counter is zero or automatically measured. Check the phone's own Data usage / Hotspot & tethering screen and enter the cumulative amount since the package start date.
- **Total used:** WiFi usage + entered hotspot usage. Avoid entering the WiFi figure again as hotspot usage, or it will be double-counted.
- **Daily chart:** Last seven calendar days of Android-reported WiFi usage only.
- **Alerts:** WorkManager checks at a 15-minute minimum interval; Android may delay background work. 20% and 10% alerts require notification permission and Usage Access.

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35. The separate GitHub Actions workflow is supplied in the chat.

## First use
1. Install and open the app.
2. Add package GB and package start date.
3. Grant Usage Access in Android Settings.
4. Enter the cumulative hotspot amount (if any) using **Update Hotspot Usage**.
